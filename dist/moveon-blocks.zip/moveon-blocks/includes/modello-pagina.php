<?php
/**
 * Modello "MoveOn · pagina intera": header, contenuto della pagina (WPBakery), footer.
 * Header, footer e le altre parti fisse si modificano da MoveOn → Modelli HTML.
 */

defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?><?php echo empty( mo_settings()['tema_scuro'] ) ? ' data-theme="light"' : ''; ?><?php echo mo_testa_chiara() ? ' class="mo-testa-chiara"' : ''; ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<script>
/* Prima che la pagina compaia: classe "mo-js" e breve caricamento iniziale
   (non con "riduci movimento", non dentro l'editor di WPBakery, non nelle pagine dei progetti). Si chiude da solo entro 2,4 s. */
(function(){var d=document.documentElement;d.classList.add('mo-js');if(<?php echo mo_is_progetti_view() ? 'false&&' : ''; ?>!/[?&]vc_editable=true/.test(location.search)&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){d.classList.add('mo-is-loading');setTimeout(function(){d.classList.remove('mo-is-loading')},2400)}})();
/* Passaggio animato tra le pagine (View Transitions): se il browser lo interrompe non è un errore, solo niente animazione */
['pageswap','pagereveal'].forEach(function(t){addEventListener(t,function(e){var v=e.viewTransition;if(v){['ready','finished','updateCallbackDone'].forEach(function(k){if(v[k]&&v[k].catch){v[k].catch(function(){})}})}})});
</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
wp_body_open();
echo MO_Tpl::render( 'parti/caricamento' ); // phpcs:ignore WordPress.Security.EscapeOutput -- modello HTML
echo mo_header_html(); // phpcs:ignore WordPress.Security.EscapeOutput
?>
<main id="mo-main" class="mo-content">
<?php
if ( is_post_type_archive( MO_CPT ) ) {
	echo mo_progetti_archivio_html(); // phpcs:ignore WordPress.Security.EscapeOutput -- modello HTML
} elseif ( is_singular( MO_CPT ) ) {
	echo mo_progetto_pagina_html( get_queried_object() ); // phpcs:ignore WordPress.Security.EscapeOutput -- modello HTML
} else {
	while ( have_posts() ) {
		the_post();
		the_content();
	}
}
?>
</main>
<?php
echo mo_footer_html(); // phpcs:ignore WordPress.Security.EscapeOutput
wp_footer();
?>
</body>
</html>
